Silchar Archive Durga Puja Pandal Guide

Responsive single-page website with search, locality filters, pandal cards, details, and Google Maps search directions.
Updated Oct 2026: varied Maa Durga / Durga Puja image links and an emergency help section.

Emergency numbers shown: 112 (all-in-one emergency), 108 (ambulance/medical), 181 (Assam Women Helpline), 1098 (Child Helpline).
Hospital listings include map links. Phone numbers may change; verify before relying on them. Use 112/108 for urgent emergencies.
Some pandal addresses and images are still provisional and should be verified/updated with real committee details.
